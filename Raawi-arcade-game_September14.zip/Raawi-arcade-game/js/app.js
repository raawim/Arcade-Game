
// Enemies our player must avoid
var Enemy = function(x,y,speed) {
    this.x = x;
    this.y =  y + 55;
    this.speed = speed;
    this.sprite = 'images/enemy-bug.png';
    this.stepper = 101;
    this.boundary = this.stepper * 5;
    this.resetPos = -this.stepper;
    // Variables applied to each of our instances go here,
    // we've provided one for you to get started

    // The image/sprite for our enemies, this uses
    // a helper we've provided to easily load images
    
};

var successCounter =0;
document.getElementById('playerSuccess').innerHTML = successCounter;



// Update the enemy's position, required method for game
// Parameter: dt, a time delta between ticks
Enemy.prototype.update = function(dt) {
    if(this.x < this.boundary)
    {
        this.x += this.speed * dt;
    }
    else{
        this.x = this.resetPos;
        
    }
    // You should multiply any movement by the dt parameter
    // which will ensure the game runs at the same speed for
    // all computers.
};

// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// Now write your own player class
// This class requires an update(), render() and
// a handleInput() method.
class Hero {
    constructor(){
        this.x = 0;
        this.y = 0;
        this.sprite = 'images/char-pink-girl.png';
        this.stepper = 101;
        this.jumper = 83;
        this.startXpos = this.stepper * 2;
        this.startYpos = (this.jumper * 5) + 55;
        this.x = this.startXpos;
        this.y = this.startYpos;
        this.victory = false;
    }
    update(){
        for(let enemy of allEnemies){
            if(this.y === enemy.y && (enemy.x +enemy.stepper/2 > this.x && enemy.x <this.x +this.stepper/2)){
                successCounter ++;
            console.log('successCounter:'+successCounter);
            document.getElementById('playerSuccess').innerHTML = successCounter;
            this.reset();
            }
            if(this.y === 55) {
                this.x=this.startXpos;
                this.y=this.startYpos;
                                this.victory = true;
                                
                                
            }
        }
    }
    reset(){
        this.y = this.startYpos;
        this.x = this.startXpos;
        successCounter= 0;
            document.getElementById('playerSuccess').innerHTML = successCounter;

            // toggle background after collision between player and enemies
            document.querySelector('body').style.backgroundColor = 'red';
            setTimeout(function () {
                document.querySelector('body').style.backgroundColor = 'white';
            }, 200);
        
    }
    
    render(){


        ctx.drawImage(Resources.get(this.sprite), this.x, this.y);

    }
    /**In order to update hero's x and y properties according to input 
     * received from keyboard */

   handleInput(input){
    switch(input) {
        case 'left' :
            if(this.x > 0) {
                this.x -= this.stepper;
            }
            break;
        case 'up' :
            if(this.y > 0) {
            this.y -= this.jumper;
            }            
            break;
        case 'right' :
            if(this.x <this.stepper * 4){
                this.x += this.stepper;
            }
            break;
        case 'down' :
            if(this.y < this.jumper * 4){
                this.y += this.jumper;
                
            }
            break;   
    }
    

   }
}

const player = new Hero();
const bugger = new Enemy(-101,0,200);
const bugger2 = new Enemy(-101,83,300);
const bugger3 = new Enemy((-101*2.5), 83, 300);
const allEnemies = [];
allEnemies.push(bugger, bugger2,bugger3);
// Now instantiate your objects.
// Place all enemy objects in an array called allEnemies
// Place the player object in a variable called player



// This listens for key presses and sends the keys to your
// Player.handleInput() method. You don't need to modify this.
document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});
